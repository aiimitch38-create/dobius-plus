import {OrbCharacter,type CharacterForm,type CharacterState} from 'orb-character';
import 'orb-character/style.css';

export interface AgentSignal{
 state:CharacterState;
 inputVolume:number;
 outputVolume:number;
}
/** Use from an Electron renderer or a normal React app. Your voice SDK owns this signal. */
export function AgentCharacter({signal,form='face'}:{signal:AgentSignal;form?:CharacterForm}){
 const level=signal.state==='listening'?signal.inputVolume:signal.state==='speaking'?signal.outputVolume:undefined;
 return <OrbCharacter form={form} state={signal.state} activity={level} facing="front" size={320}/>;
}
