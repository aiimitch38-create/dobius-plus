# Orb Character for React / Electron

A reusable character with two forms and four conversation states. It contains the exact preset snapshot exported from your browser, including your colors, sizes, motion values, signal strengths, underlight settings, and editor lock flags.

| Control | Values |
| --- | --- |
| Form | `orb`, `face` |
| State | `idle`, `listening`, `thinking`, `speaking` |
| Facing | `front`, `right`, `left` (used by the face) |

## Install in your existing app

Install the included local npm archive from your app's project folder:

```sh
npm install /path/to/orb-character-1.0.0.tgz
```

React 18 or 19 must already be installed in the app. Three.js is installed automatically as the character's dependency. The character runs in the Electron **renderer** or a normal browser. It uses no Node APIs, IPC permissions, network service, microphone permission, or Electron security-setting changes.

## Use it

```tsx
import {OrbCharacter} from 'orb-character';
import 'orb-character/style.css';

<OrbCharacter
  form="face"
  state="listening"
  activity={inputVolume} // normalized 0–1 from your voice SDK or analyser
  facing="front"
  size={320}
/>
```

Change `form` to `orb` for the original particle orb. Change `state` independently; the same component transitions between forms and states without remounting its particle mesh.

Both forms support all four states:

- **Idle:** gentle ambient motion; the face also blinks.
- **Listening:** reactive surface motion; the face opens its eyes attentively.
- **Thinking:** the original orb becomes three flowing balls; the face keeps its sphere and uses a pondering glance and squint.
- **Speaking:** syllable-driven articulation and pauses; the face also moves its eyes with voice energy.

## Connect actual voice activity

Your application owns the conversation lifecycle. Set Listening while receiving speech, Thinking while awaiting the agent response, Speaking while playing the response, and Idle when the conversation is inactive.

Pass microphone input level during Listening and playback output level during Speaking. `activity` is a normalized number from 0 to 1. The character applies your saved Signal Strength as a gain. A supplied `0` is real silence, not a request to play the demo. No audio is generated or captured by the character itself.

If `activity` is omitted, the built-in visual preview runs, including the simulated speaking rhythm. This makes state-only previews work before a voice SDK is connected. See `examples/AgentCharacter.tsx` for a small controlled integration.

## Appearance and settings

`SAVED_PRESETS` exports the captured settings. You can inspect the same snapshot in `src/presets.json` (source archive) or `orb-character/presets.json` (installed package).

The package is independent of the playground's localStorage. It therefore keeps your exported appearance when installed in your software. Later playground edits do not silently change an already-built package: export a new snapshot and rebuild it when you want an updated release.

Optional partial overrides are merged per state:

```tsx
<OrbCharacter
  form="orb"
  state="speaking"
  activity={outputVolume}
  presets={{speaking: {motionAmount: 4.5}}}
/>
```

The captured `locked` values document your editor choices; they do not prevent your app from changing the character's form or conversation state.

## Other props

- `paused`: freezes continuous motion. Defaults to `false`.
- `size`: responsive maximum square width, in CSS pixels. Defaults to `320`. `style` and `className` can size it through your app's layout.
- `background`: a hex color or `transparent` for overlays. Defaults to white.
- `quality`: `full` for the original bead density, or `preview` for lighter rendering.
- `facing`: `front` by default; `right` and `left` rotate the face.
- `fallbackImage`: optional static image if WebGL cannot initialize. A self-contained CSS fallback is otherwise used.
- Normal React div attributes, including an accessible `aria-label`, are accepted.

Reduced-motion preferences are respected. Drawing stops when the component is offscreen. Unmounting releases its WebGL resources and observers. The stylesheet is scoped to `.orb-character` and does not restyle your app's controls.

## Build from the source archive

Use Node.js 22 or newer for development:

```sh
npm install
npm run build
npm test
npm pack
```

`dist/` contains the ready-to-import ES module, stylesheet, TypeScript declarations, and exact preset JSON. The npm archive contains compiled files and the integration example; the source ZIP also contains editable source and tests.

This deliverable is a reusable renderer package. It has not been inserted into a specific app repository because no target repository was provided.
